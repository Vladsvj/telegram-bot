config = {
	'name': 'PartnerHubot',
	'token': '7876593451:AAGWOLSyy6tDMJMFKpc5Nddk5WuLlpVkAac'
}